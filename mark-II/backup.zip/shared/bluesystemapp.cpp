#include "bluesystemapp.h"

bluesystemApp::bluesystemApp(QJsonValue & initdata, QObject *parent) : nd::app(initdata, parent)
{

}
