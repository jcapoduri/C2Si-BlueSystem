#include "global_scope.h"

bluesystemApp *app;
QJsonObject   blueBusiness;
