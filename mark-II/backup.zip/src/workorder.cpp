#include "workorder.h"

workorder::workorder(QJsonValue initdata, QObject *parent) : nd::object(initdata, parent)
{
}

workorder::workorder()
{
}
