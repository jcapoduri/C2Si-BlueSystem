#include "job.h"

job::job(QJsonValue initdata, QObject *parent) :
    nd::object(initdata, parent)
{
}
