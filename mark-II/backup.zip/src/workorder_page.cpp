#include "workorder_page.h"

workorderPage::workorderPage(QJsonValue initdata, QObject *parent) :
    nd::object(initdata, parent)
{
}

workorderPage::workorderPage()
{
}
