#include "user.h"

user::user(QJsonValue &initdata, QObject *parent) :
    nd::object(initdata, parent)
{
}
