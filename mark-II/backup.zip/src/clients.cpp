#include "clients.h"

client::client(QJsonValue initdata, QObject *parent) : nd::object(initdata, parent)
{
}

client::client()
{
}
