#include "business.h"

business::business(QJsonValue initdata, QObject *parent) :
    nd::object(initdata, parent)
{
}

business::business()
{
}

