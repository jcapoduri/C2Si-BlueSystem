#ifndef GLOBAL_SCOPE_H
#define GLOBAL_SCOPE_H

#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include "bluesystemapp.h"

extern bluesystemApp *app;
extern QJsonObject   blueBusiness;

#endif // GLOBAL_SCOPE_H
